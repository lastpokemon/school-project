<?php
$title = "Home";
$content = '<img src="Images/coffee1.png" class="imgLeft" />
<h3>Title 1</h3>
<p>
   It problems fixed in not time bla bla bla bla
   bla bla abl
   

</p>

<img src="Images/coffee2.png" class="imgRight"/>
<h3>Title 2</h3>
<p>
    more blabla bla and we provide even more bla bla
</p>';


include 'Template.php';
?>
